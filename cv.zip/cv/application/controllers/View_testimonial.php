<?php

	class Testimonial_view extends CI_Controller {
		public function __construct() {
			parent::__construct();
			$this->load->model('Testimonial_view_model');
		}
		
		public function index() {
			$query['data'] = $this->Testimonial_view_model->get_all_testimonial();
			$this->load->view('Home',$query);

		}
	}
