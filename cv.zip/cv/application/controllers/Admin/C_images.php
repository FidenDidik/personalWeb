<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_images extends CI_Controller {

	public  function __construct(){
	parent::__construct();
	$this->load->model("Images_model");

	}
	
	public function index() {
		if($this->session->user_login === TRUE) {
			$query['data'] = $this->Images_model->view();
			$this->load->view('backend/view_images', $query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}

		public function add_images()
	{
		if($this->input->post('submit'))
		{
			$this->form_validation->set_rules('nis','nis is required','trim|required|numeric|is_unique[student.nis]|min_length[4]|max_length[4]');
			$this->form_validation->set_rules('nama_lengkap','nama lengkap is required','trim|required|alpha_spaces');
			$this->form_validation->set_rules('jenis_kelamin','jenis kelamin is required','trim|required');
		
			if($this->form_validation->run() === FALSE) {
                $data_error = array(
                'error' => '',
            );
             $this->load->view('backend/view_images',$data_error);
         	}
         	else 
         	{
			$config = array(
					'upload_path' => './upload/',
					'allowed_types' => 'jpg|jpeg|png',
					'max_size' => '5120',
					'max_width' => '4272',
					'max_height' => '4272'
				);
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('picture'))
			 {
				$data_error = array(
						'error' => $this->upload->display_errors(),
					);
				$this->load->view('regis/view_insertoldst', $data_error);
			 } 
			else 
			{
				$upload_data = $this->upload->data();
				$picture = $upload_data['file_name'];

				$data_student = array(
						'nis'=>$this->input->post('nis'),
						'nama_lengkap'=>$this->input->post('nama_lengkap'),
						'jenis_kelamin'=>$this->input->post('jenis_kelamin'),
						
					);
					$this->Mdl_regis->save_student($data_student);
					$this->Mdl_regis->insertoldst($data_student);
					redirect('regis/Crud/insertoldst');
			}
		}
	}
		else {
			$this->load->library('upload');
			$data_error = array(
					'error' => $this->upload->display_errors(),
				);
			$this->load->view('regis/view_insertoldst', $data_error);
		} 
	}
