<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_pesan extends CI_Controller {

	public  function __construct(){
	parent::__construct();
	$this->load->model("Pesan_model");

	}
	
	public function save_pesan() {
		
			// set rules untuk validasi
			$this->form_validation->set_rules('fullname', 'fullname', 'trim|required');
			$this->form_validation->set_rules('email', 'email', 'trim|required');	
			$this->form_validation->set_rules('pesan', 'pesan', 'trim|required');
			
			if($this->form_validation->run() === FALSE) {
				$this->load->view('Login');
			} else {
				$tgl = date("Y-m-d");
				
				$data = array(
					'fullname' => $this->input->post('fullname'),
					'email' => $this->input->post('email'),
					'pesan' => $this->input->post('pesan'),
					'date' => $tgl
				);
				$this->Pesan_model->insert_pesan($data);
				
				$this->session->set_flashdata('pesan', 'success_add');
				redirect('#hire-sec');
			}
	}
	public function index() {
		if($this->session->userdata('user_login') === TRUE) {
			// melakukan query untuk mengambil semua news di database
			$query['data'] = $this->Pesan_model->view_pesan();
			
			// load view all news dengan daftar news yang ada
			$this->load->view('backend/view_pesan', $query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
	public function delete_pesan(){
		if($this->session->user_login === TRUE) {
		$id = $this->uri->segment(4);
		$this->Pesan_model->delete_pesan($id,$data);
				
				$this->session->set_flashdata('pesan', 'success_delete');
				redirect('admin/C_pesan/index');
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}

	}
}

