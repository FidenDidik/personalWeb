<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_about extends CI_Controller {

	public  function __construct(){
	parent::__construct();
	$this->load->model("About_model");

	}
	
	public function index() {
		if($this->session->user_login === TRUE) {
			$query['data'] = $this->About_model->view_about();
			$this->load->view('backend/view_about', $query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}

	public function edit_about() {
		if($this->session->userdata('user_login') === TRUE) {
			$id = $this->uri->segment(4);
			$query['data'] = $this->About_model->show_id($id);
			$this->load->view('backend/view_edit_about',$query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
	public function update_about(){
		if($this->session->userdata('user_login') === TRUE) {
	    $id = $this->input->post('id_about');
		$data = array(
	   'about' => $this->input->post('about'),
	    'about1' => $this->input->post('about1'),
		);		
		$this->About_model->update_about($id,$data);		
		$this->session->set_flashdata('about', 'success_edit');
		redirect('Admin/C_about/index');
	}else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
}

