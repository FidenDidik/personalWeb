<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class C_testimonial extends CI_Controller {

	public  function __construct(){
	parent::__construct();
	$this->load->model("Testimonial_model");

	}
	
	public function index() {
		if($this->session->user_login === TRUE) {
			$query['data'] = $this->Testimonial_model->view();
			$this->load->view('backend/view_testimonial', $query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
	public function add_testimonial() {
		if($this->session->user_login === TRUE) {
			$this->load->view('backend/view_add_testimonial');
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}

	public function save_testimonial() {
		if($this->session->user_login === TRUE) {
			// set rules untuk validasi
			$this->form_validation->set_rules('testi1', 'testi1', 'trim|required');
			$this->form_validation->set_rules('testi2', 'testi2', 'trim|required');
			$this->form_validation->set_rules('testi3', 'testi3', 'trim|required');
			$this->form_validation->set_rules('by1', 'by1', 'trim|required');
			$this->form_validation->set_rules('by2', 'by2', 'trim|required');
			$this->form_validation->set_rules('by3', 'by3', 'trim|required');
			$this->form_validation->set_rules('photo1', 'photo1', 'trim|required');
			$this->form_validation->set_rules('photo2', 'photo2', 'trim|required');
			$this->form_validation->set_rules('photo3', 'photo3', 'trim|required');
		

			if($this->form_validation->run() === FALSE) {
				$this->load->view('backend/view_testimonial');
			} else {
				
				$data = array(
				
					'testi1' => $this->input->post('testi1'),
					'testi2' => $this->input->post('testi2'),
					'testi3' => $this->input->post('testi3'),
					'by1' => $this->input->post('by1'),
					'by2' => $this->input->post('by2'),
					'by3' => $this->input->post('by3'),
					'photo1' => $this->input->post('photo1'),
					'photo2' => $this->input->post('photo2'),
					'photo3' => $this->input->post('photo3'),
					
				);

				$this->Testimonial_model->insert_testimonial($data);
				
				$this->session->set_flashdata('testimonial', 'success_add');
				redirect('admin/C_testimonial/index');
				}		
		    } else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
	
	public function delete_testimonial(){
		if($this->session->user_login === TRUE) {
		$id = $this->uri->segment(4);
		$this->Testimonial_model->delete_testimonial($id,$data);
				
				$this->session->set_flashdata('testimonial', 'success_delete');
				redirect('Admin/C_testimonial/index');
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}

	}
	public function edit_testimonial() {
		if($this->session->userdata('user_login') === TRUE) {
			$id = $this->uri->segment(4);
			$query['data'] = $this->Testimonial_model->show_id($id);
			$this->load->view('backend/view_edit_testimonial',$query);
		} else {
			$this->session->set_flashdata('login', 'bypass');
			redirect('Login');
		}
	}
	public function update_testimonial(){
	    $id = $this->input->post('id_testi');
		$data = array(
				   	'testi1' => $this->input->post('testi1'),
					'testi2' => $this->input->post('testi2'),
					'testi3' => $this->input->post('testi3'),
					'by1' => $this->input->post('by1'),
					'by2' => $this->input->post('by2'),
					'by3' => $this->input->post('by3'),
					'photo1' => $this->input->post('photo1'),
					'photo2' => $this->input->post('photo2'),
					'photo3' => $this->input->post('photo3'),
					);
				
		         $this->Testimonial_model->update_testimonial($id,$data);
				
				$this->session->set_flashdata('testimonial', 'success_edit');
				redirect('Admin/C_testimonial/index');
	}
}

