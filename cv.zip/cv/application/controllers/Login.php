<?php
class Login extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->helper('form');
		$this->load->model('Login_model');

	}
	
	public function index() {
		$this->load->view('backend/view_login');
	}
	
	public function cek_user_login() {
		// membuat rules untuk proses validasi
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		// menjalankan proses validasi
		if($this->form_validation->run() === FALSE) {
			$this->load->view('backend/view_login');
			
		} else {
			$username = $this->input->post('username');
			$password = md5($this->input->post('password'));
			
			$cek = $this->Login_model->cek_user($username, $password);
			
			if($cek > 0) {
				// deklarasi variabel session dalam bentuk array
				$newdata = array(
					'id' => $cek->id,
					'fullname' => $cek->fullname,
					'usename' => $cek->username,
					'level' => $cek->level,
					'user_login' => TRUE
				);
				// set session
				$this->session->set_userdata($newdata); 
				if($cek->level === 'admin') {

					redirect('Admin/C_dashboard');

				} else if($cek->level === 'dosen') {
					redirect('dosen/C_dashboard_dosen');
					
				} else if($cek->level === 'user') {
					redirect('user/C_dashboard_user');
				} else {
					redirect('C_dashboard');
				}

			} else {
				redirect('Login');
				
			}
		}redirect('Login');
	}
	
	public function logout() {
		$this->session->sess_destroy();
		redirect('Login');
	}
}
