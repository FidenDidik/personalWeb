<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class C_Home extends CI_Controller {
	public  function __construct(){
	parent::__construct();
	$this->load->helper(array('url','download'));
		$this->load->model("Testimonial_view_model");
			$this->load->model("About_model");

    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{   
		  $query['testimonial'] = $this->Testimonial_view_model->get_all_testimonial();
          $query['about'] = $this->About_model->view_about();
		
		  $this->load->view('Home',$query);


		

	}
	public function lakukan_download(){				
		force_download('assets/download/CURRICULUM VITAE.pdf',NULL);
	}
	

}
