<?php
class Testimonial_view_model extends CI_Model
{
	
	function __construct()
	{
		# code...
		parent:: __construct();
	}

	   function get_all_testimonial(){
         $sql = $this->db->query("SELECT * FROM testimonial");
        return $sql;
    
        }
    }
