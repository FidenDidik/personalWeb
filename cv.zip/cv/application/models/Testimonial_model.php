<?php
class Testimonial_model extends CI_Model
{
    
    function __construct()
    {
        # code...
        parent:: __construct();
    }
     public function view(){
        $this->db->select('*');
        $this->db->from('testimonial');
        $this->db->order_by('id_testi');
        $query = $this->db->get();
        return $query;
    }
    public function insert_testimonial ($data){
        $this->db->insert('testimonial',$data);
    }
    public function delete_testimonial($id){
        $this->db->where('id_testi', $id);
        $this->db->delete('testimonial');
    }
    public function show_id($data){
    $this->db->select('*');
    $this->db->from('testimonial');
    $this->db->where('id_testi', $data);
    $query = $this->db->get();
    $result = $query->result();
    return $result;
    }
// Update Query For Selected students
    public function update_testimonial($id,$data){
    $this->db->where('id_testi', $id);
    $this->db->update('testimonial', $data);
    }

}


