<?php
class About_model extends CI_Model
{
    
    function __construct()
    {
        # code...
        parent:: __construct();
    }
     public function view_about(){
         $sql = $this->db->query("SELECT * FROM about");
        return $sql;
    }
    public function show_id($data){
    $this->db->select('*');
    $this->db->from('about');
    $this->db->where('id_about', $data);
    $query = $this->db->get();
    $result = $query->result();
    return $result;
    }
// Update Query For Selected students
    public function update_about($id,$data){
    $this->db->where('id_about', $id);
    $this->db->update('about', $data);
    }
}

