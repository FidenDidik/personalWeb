<?php
class Pesan_model extends CI_Model
{
    
    function __construct()
    {
        # code...
        parent:: __construct();
    }
    function view_pesan(){
        $this->db->select('*');
        $this->db->from('pesan');
        $query = $this->db->get();
        if($query->num_rows() > 0){
        return $query->result();
        }
    }
    public function insert_pesan ($data){
        $this->db->insert('pesan',$data);
    }
    public function delete_pesan($id){
        $this->db->where('id_pesan', $id);
        $this->db->delete('pesan');
    }
}
