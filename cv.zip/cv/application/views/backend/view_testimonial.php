<?php $this->load->view('backend/header.php'); ?>

<?php if($this->session->flashdata('pesan') === 'success_delete') { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            Msagges has been successfully deleted.
                            </div>
                            <?php } ?>
 
 <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> List Of Testimonial
                            <div class="pull-right">
                              
                            </div>
                        </div>

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead>
                                                <tr>
                                               
                                                   
                                                        <th>By1</th>
                                                        <th>By2</th>
                                                        <th>By3</th>
                                                        <th>Photo1</th>
                                                        <th>Photo2</th>
                                                        <th>Photo3</th>
                                                        <th>Testimonial 1</th>
                                                        <th>Testimonial 2</th>
                                                        <th>Testimonial 3</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                   
                                                    foreach ($data->result() as $row) { ?>



                                                    <td class="text-center"><?php echo $row->by1; ?></td>
                                                    <td class="text-center"><?php echo $row->by2; ?></td>
                                                    <td class="text-center"><?php echo $row->by3; ?></td>
                                                    <td class="text-center"><?php echo $row->photo1; ?></td>
                                                    <td class="text-center"><?php echo $row->photo2; ?></td>
                                                    <td class="text-center"><?php echo $row->photo3; ?></td>  
                                                    <td class="text-center"><?php echo $row->testi1; ?></td>
                                                    <td class="text-center"><?php echo $row->testi2; ?></td>
                                                    <td class="text-center"><?php echo $row->testi3; ?></td>
                                                    <td>
                                                    <a href="<?php echo base_url(); ?>index.php/Admin/C_testimonial/edit_testimonial/<?php echo $row->id_testi;?>" class="btn btn-success">Updaate</a>&nbsp;
                                                    </td>
                                                    </tr>
                                                    <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>

                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
<?php $this->load->view('backend/footer.php'); ?>
