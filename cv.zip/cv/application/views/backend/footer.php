
        </div>
        <!-- end page-wrapper -->

    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/jquery-1.10.2.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/pace/pace.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/plugins/morris/morris.js"></script>
    <script src="<?php echo base_url(); ?>assets/backend/assetsD/scripts/dashboard-demo.js"></script>

</body>

</html>