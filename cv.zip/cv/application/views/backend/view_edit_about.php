<?php $this->load->view('backend/header.php');?>
 <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i>About me
                            <div class="pull-right">
                              
                            </div>
                        </div>

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">
                       </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <?php 
                                    $attrib = array('role'=>'form');
                                    echo form_open('Admin/C_about/update_about', $attrib); 
                                    ?>
                                   <div class="form-group">

                                   <?php foreach ($data as $row) : ?>
                                   <label>About 1</label>
                                   <input type="text" name="about" class="form-control" value="<?php echo $row->about; ?>">
                                   <p> <?php echo form_error('about'); ?> </p>  

                                    <input type="hidden" id="hide" name="id_about" value="<?php echo $row->id_about; ?>">
                                   <label>About 2</label>
                                   <input type="textarea" name="about1" class="form-control" value="<?php echo $row->about1; ?>">
                                   <p> <?php echo form_error('about1'); ?> </p>

                                   <?php endforeach ?>
                                   <input type="submit" class="btn btn-primary" value="Update">&nbsp;
                                    <a href="<?php echo base_url(); ?>index.php/Admin/C_about/index" class="btn btn-danger">Cancel</a>
                                  <?php echo form_close(); ?>
                       
                                 </div>
                             </div>
                         </div>
                      </div>
                 </div>
              </div>
</div>
<?php $this->load->view('backend/footer.php');?>