<?php $this->load->view('backend/header.php'); ?>

<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Form add Student
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
<?php 
 $attrib = array('role'=>'form');
 echo form_open('Admin/C_testimonial/save_testimonial', $attrib); 
                                    ?>
                                    <div class="form-group">
                                    <label>Testimonial 1</label>
                                    <input type="text" name="testi1" class="form-control">
                                    <p> <?php echo form_error('testi1'); ?> </p>
                                    
                                    <div class="form-group">
                                    <label>By</label>
                                    <input type="text" name="by" class="form-control">
                                    <p> <?php echo form_error('by'); ?> </p>
  
                                    <div class="form-group">
                                    <label>Photo</label>
                                    <input type="text" name="photo" class="form-control">
                                    <p> <?php echo form_error('photo'); ?> </p>
                                    </div>

                                  <input type="submit" class="btn btn-primary" value="Add Testimonial">
                                 <a href="<?php echo base_url(); ?>index.php/admin/C_testimonial/index" class="btn btn-warning">Cancel</a>
                                  <?php echo form_close(); ?>
                                 </div>
                             </div>
                         </div>
                      </div>
                 </div>
              </div>
</div>
</div>
</div>
<?php $this->load->view('backend/footer.php'); ?>