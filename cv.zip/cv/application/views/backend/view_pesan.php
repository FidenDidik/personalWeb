<?php $this->load->view('backend/header.php'); ?>

<?php if($this->session->flashdata('pesan') === 'success_delete') { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            Msagges has been successfully deleted.
                            </div>
                            <?php } ?>
 
 <div class="panel panel-primary">
                        <div class="panel-heading">
                            <i class="fa fa-bar-chart-o fa-fw"></i> List of Messages
                            <div class="pull-right">
                              
                            </div>
                        </div>

                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Fullname</th>
                                                    <th>Email</th>
                                                    <th>Messages</th>
                                                    <th>Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $no=1;  
                                                    foreach ($data as $row) { ?>

                                                    <td class="text-center"><?php echo $no; ?></td>
                                                    <td class="text-center"><?php echo $row->fullname ?></td>
                                                    <td class="text-center"><?php echo $row->email ?></td>
                                                    <td class="text-center"><p><?php echo $row->pesan ?></p></td>
                                                    <td class="text-center"><?php echo $row->date ?></td>
                                                    <td>
                                                      <a href="javascript:if(confirm('are you sure want to delete')){document.location='<?php echo base_url(); ?>index.php/Admin/C_pesan/delete_pesan/<?php echo $row->id_pesan; ?>';}"class="btn-sm btn-danger"> Delete</a>&nbsp;
         
                                                
                                                    </td>
                                                    </tr>
                                                    <?php 
                                                    $no++;
                                                    } ?>

                                            </tbody>
                                        </table>
                                    </div>

                                </div>

                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
<?php $this->load->view('backend/footer.php'); ?>
