<!DOCTYPE html>
<html xmlns=" ">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>Didik Fiden Personal Portfolio </title>
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/font-awesome.min.css" rel="stylesheet" />
    <!-- ANIMATE  CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/animate.css" rel="stylesheet" />
    <!-- PRETTY PHOTO  CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/prettyPhoto.css" rel="stylesheet" />
    <!--  STYLE SWITCHER CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/styleSwitcher.css" rel="stylesheet" />
    <!-- CUSTOM STYLE CSS -->
    <link href="<?php echo base_url()."assets" ?>/css/style.css" rel="stylesheet" />
    <!--PINK STYLE VERSION IS BY DEFAULT, USE ANY ONE STYLESHEET FROM FOUR STYLESHEETS (pink,green,blue and brown) HERE-->
    <link href="<?php echo base_url()."assets" ?>/css/themes/pink.css" id="mainCSS" rel="stylesheet" />
    <!-- GOOGLE FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css' />

</head>
<body>
       
    <div class="switcher" style="left:-50px;">
        <a id="switch-panel" class="hide-panel">
            <i class="fa fa-desktop"></i>

        </a>
        <p style="font-size:10px">choose</p>
        <ul class="colors-list">
        <li><a title="Blue" id="blue" class="blue" ></a></li>
         <li><a title="Pink" id="pink" class="pink" ></a></li>
         <li><a title="Green" id="green" class="green" ></a></li>
        <li><a title="Brown" id="brown" class="brown" ></a></li>
           
        </ul>
    </div>	
    <!-- /. END THEME SWITCHER-->

    <div id="home-sec">
        <div class="overlay">
            <div class="container">
           
                <div class="row pad-top-bottom  move-me">
                    <div class="col-lg-5 col-md-5 col-sm-5 text-center">
                        <img src="<?php echo base_url();?>assets/img/d1.jpg" class="main-img img-circle wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s" alt=""/>
                        <h1 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">DIDIK HANANYA FIDEN</h1>
                        <h4 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".6s">WEB DEPLOVER & GRAPHIC DESIGN</h4>
                        <a href="#about-sec" class="btn custom-btn-one btn-lg wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".8s">EXPLORE MYSELF</a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 text-center  ">
                        <a href="#about-sec" class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".1s">
                            <i class="fa fa-info icon-round icon-round"></i>
                            <h3 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">ABOUT ME</h3>
                        </a>
                        <a href="#resume-sec" class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".3s">
                            <i class="fa fa-briefcase icon-round"></i>
                            <h3 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">RESUME</h3>
                        </a>
                        <a href="#portfolio-sec" class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".5s">
                            <i class="fa fa-recycle icon-round icon-round"></i>
                            <h3 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".6s">PORTFOLIO </h3>
                        </a>
                        <a href="#hire-sec" class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".7s">
                            <i class="fa fa-paper-plane-o icon-round"></i>
                            <h3 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".8s">HIRE ME</h3>
                        </a>
                    </div>
                    <div class="col-lg-5 col-md-5 col-sm-5 text-center">
                        <img src="<?php echo base_url();?>assets/img/d2.jpg" class="main-img img-circle wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s" alt="" />
                        <h1 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">FRASH GRADUATE</h1>
                        <h4 class="wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".6s">BACHELOR DEGREE INFORMATION SYSTEM</h4>
                        <a href="#resume-sec" class="btn custom-btn-one btn-lg wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".8s">DOWNLOAD RESUME</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- HOME SECTION END-->
    <section id="about-sec">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-4 wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                    <h1>WHAT TO KNOW</h1>
                    <h1>ABOUT ME ?</h1>
                    <div class="color-strip"></div>
                    <div class="social-icon">
                        <a href="#">
                            <img src="<?php echo base_url();?>assets/img/Social/facebook.png" alt="" /></a>
                        <a href="#">
                            <img src="<?php echo base_url();?>assets/img/Social/google-plus.png" alt="" /></a>
                        <a href="#">
                            <img src="<?php echo base_url();?>assets/img/Social/twitter.png" alt="" /></a>
                    </div>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8 wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">
                <?php
                 foreach ($about->result() as $row) {?>
                    <p>
                     <?php echo $row->about; ?></p>
                      <p>
                      <?php echo $row->about1; ?></p>

                  
                    <?php }?>
                      <?php echo form_close(); ?>
                </div>
            </div>
        </div>
    </section>
    <!-- ABOUT SECTION END-->
    <section id="skill-sec">
        <div class="overlay">
            <div class="container">
                <div class="row pad-top-bottom move-me">
                    <div class="col-lg-2 col-md-2 col-sm-2 text-center wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                        <span class="chart" data-percent="87">
                            <span class="percent"></span>
                        </span>
                        <h4>CODEIGNAITER</h4>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 text-center wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">
                        <span class="chart" data-percent="90">
                            <span class="percent"></span>
                        </span>
                        <h4>HTML</h4>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 text-center  wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".6s">
                        <span class="chart" data-percent="78">
                            <span class="percent"></span>
                        </span>
                        <h4>PHP </h4>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-2 text-center wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".8s">
                        <span class="chart" data-percent="87">
                            <span class="percent"></span>
                        </span>
                        <h4>GRAPHIC DESIGN</h4>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-2 text-center wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".8s">
                        <span class="chart" data-percent="83">
                            <span class="percent"></span>
                        </span>
                        <h4>3D DESIGN</h4>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-2  wow bounceIn animated" data-wow-duration="1s" data-wow-delay="1s">
                        <h1>CHECKOUT MY SKILL SET</h1>
                       
                      
                        <a href="#resume-sec" class="btn btn-style-two">DOWNLOAD RESUME (.pdf)</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- SKILL SECTION END-->
    <section id="resume-sec">
        <div class="container">
            <div class="row  move-me">
                <div class="col-lg-4 col-md-4 col-sm-4 wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                    <h1>DOWNLOAD </h1>
                    <h1>RESUME</h1>
                    <div class="color-strip"></div>
                    <a href="<?php echo base_url().'index.php/C_Home/lakukan_download' ?>" class="btn btn-style-three ">DOWNLOAD RESUME (.pdf file)</a>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8 wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">

                    <div class="board">
                        <div class="board-inner">
                            <ul class="nav nav-tabs" id="myTab">
                                <li class="active">
                                    <a href="#home" data-toggle="tab" title="PERSONAL DETAILS">
                                        <span class="round-tabs one">
                                            <i class="fa fa-home"></i>
                                        </span>
                                    </a></li>

                                <li><a href="#profile" data-toggle="tab" title="EDUCATIONAL PROFILE">
                                    <span class="round-tabs two">
                                        <i class="fa fa-briefcase"></i>
                                    </span>
                                </a>
                                </li>
                                <li><a href="#exp" data-toggle="tab" title="EXPERIENCE DETAILS">
                                    <span class="round-tabs three">
                                        <i class="fa fa-recycle"></i>
                                    </span></a>
                                </li>

                                <li><a href="#location" data-toggle="tab" title="PRESENT LOCATION">
                                    <span class="round-tabs four">
                                        <i class="fa fa-paper-plane-o"></i>
                                    </span>
                                </a></li>

                                <li><a href="#contact" data-toggle="tab" title="CONTACT ME">
                                    <span class="round-tabs five">
                                        <i class="fa fa-comments-o"></i>
                                    </span></a>
                                </li>

                            </ul>
                        </div>

                        <div class="tab-content">
                            <div class="tab-pane fade in active" id="home">

                                <h4 class="head text-center">PERSONAL DETAILS</h4>
                                <p class="narrow text-center">
                                    <span>
                                        <i>FULLNAME : </i>DIDIK HANANYA FIDEN, S.Kom
                                    </span>
                                    <span>
                                        <i>AGE :</i>25 YEARS
                                    </span>
                                    <span>
                                        
                                    </span>
                                </p>


                            </div>
                            <div class="tab-pane fade" id="profile">

                                <h4 class="head text-center">EDUCATIONAL PROFILE</h4>
                                <p class="narrow text-center">
                                    <span>
                                        <i>INFORMATION SYSTEM : </i>S1 ( Computer Science ) 
                                    </span>
                                    <span>
                                        <i>SKILLS  :</i>HTML,CODEIGNAITER , PHP, GRAPHIC DESIGN, etc.
                                    </span>
                                    <span>
                                        <i>SOFTWARES  :</i>PHOTOSHOP, UNITY, CORELDRAW, ADOBE ILUSTRATOR etc.
                                    </span>
                                </p>
                            </div>
                            <div class="tab-pane fade" id="exp">
                                <h4 class="head text-center">EXPERIENCE DETAILS</h4>
                                <p class="narrow text-center">
                                    <span>
                                        <i>PENGADILAN NEGERI KUTAI BARAT  : </i>2010-2012 STAFF BAGIAN HUKUM
                                    </span>
                                    <span>
                                        <i>BUDAI CREATIEVS : </i>2010 - 2017 as GRAPHIC DESIGNER
                                    </span>
                                    <span>
                                        <i>SABBATH SCHOOL STAFF :</i>2015 - 2016 as PRESIDENT.
                                    </span>
                                </p>
                            </div>
                            <div class="tab-pane fade" id="location">
                                <h4 class="head text-center">PRESENT LOCATION </h4>
                                <p class="narrow text-center">
                                    <span>
                                        <i>LOCALITY </i>RT.10/ NO. 28 - JLN. HAJI NURDIN MELAK ULU
                                    </span>
                                    <span>
                                        <i>COUNTRY </i> INDONESIA
                                    </span>
                                    <span>
                                        <i>CITY </i>MELAK - KUTAI-BARAT- KALIMANTAN TIMUR
                                    </span>
                                </p>
                            </div>
                            <div class="tab-pane fade" id="contact">
                                <h4 class="head text-center">CONTACT ME </h4>

                                <p class="narrow text-center">
                                    <span>
                                        <i>EMAIL </i>didikhananya@gmail.com
                                    </span>
                                    <span>
                                        <i>Call </i>+62-8134-9019-281
                                    </span>
                                    <span>
                                        <i> BBM </i>D7D8DA48
                                    </span>
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- <div class="row pad-top  move-me wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".6s">
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="alert alert-info text-center">


                        <h4 class="media-heading"><strong>10 USD</strong> / HOUR</h4>
                        <p>
                            Aenean faucibus luctus enim.  
                        </p>
                        <a href="#hire-sec" class="btn btn-info">BUY PLAN NOW</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="alert alert-success text-center">


                        <h4 class="media-heading"><strong>200 USD</strong> / MONTH</h4>
                        <p>
                            Aenean faucibus luctus enim. 
                        </p>
                        <a href="#hire-sec" class="btn btn-success ">BUY PLAN NOW</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="alert alert-info text-center">


                        <h4 class="media-heading"><strong>1500 USD</strong> / YEAR</h4>
                        <p>
                            Aenean faucibus luctus enim.  
                        </p>
                        <a href="#hire-sec" class="btn btn-info">BUY PLAN NOW</a>
                    </div>
                </div>
            </div>

        </div> -->
    </section>
    <!-- RESUME SECTION END-->
    <section id="testimonial-main">
        <div class="overlay">
            <div class="container">
                <div class="row pad-top-bottom wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                    <div class="col-lg-12 col-md-12 col-sm-12 text-center">
                        <h1>TESTIMONIALS</h1>

                        <div id="testimonials" class="carousel slide" data-ride="carousel">

                            <ol class="carousel-indicators">
                                <li data-target="#testimonials" data-slide-to="0" class=""></li>
                                <li data-target="#testimonials" data-slide-to="1" class="active"></li>
                                <li data-target="#testimonials" data-slide-to="2" class=""></li>
                            </ol>
                          <?php
                                   foreach ($testimonial->result() as $row) {?>
                            <div class="carousel-inner">
                                <div class="item">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                          
                                            <h4><i class="fa fa-quote-left"></i><?php echo $row->testi1; ?><i class="fa fa-quote-right"></i></h4>
                                            <div class="user-img pull-right">
                                                <img src="<?php echo base_url().'assets/img/'.$row->photo1;?>" alt="" class="img-circle image-responsive" />
                                            </div>
                                            <h5 class="pull-right"><?php echo $row->by1; ?></h5>
                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="item active">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                            <h4><i class="fa fa-quote-left"></i><?php echo $row->testi2; ?><i class="fa fa-quote-right"></i></h4>
                                            <div class="user-img pull-right">
                                                <img src="<?php echo base_url().'assets/img/'.$row->photo2;?>" alt="" class="img-circle image-responsive" />
                                            </div>
                                            <h5 class="pull-right"><?php echo $row->by2; ?></h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="container center">
                                        <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 slide-custom">
                                            <h4><i class="fa fa-quote-left"></i><?php echo $row->testi3; ?><i class="fa fa-quote-right"></i></h4>
                                            <div class="user-img pull-right">
                                                <img src="<?php echo base_url().'assets/img/'.$row->photo3;?>" alt="" class="img-circle image-responsive" />
                                            </div>
                                            <h5 class="pull-right"><?php echo $row->by3; ?></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php }?>
                              <?php echo form_close(); ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- TESTIMONIAL SECTION END-->
    <section id="portfolio-sec">
        <div class="container">
            <div class="row text-center wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 text-center">
                    <h1>RECENT ACTIVITY</h1>
                    <p>I AM PART OF THEM.. </div>
            </div>
            <div class="row  wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/1.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview"  href="<?php echo base_url();?>assets/img/portfolio/big/1.jpg"><i class="fa fa-eye"></i>SEE FHOTO</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/2.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p> </p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/2.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/3.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/3.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/4.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/4.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/5.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/5.jpg"><i class="fa fa-eye"></i>SEE PHOTO</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/6.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/6.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/7.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/7.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/8.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/8.jpg"><i class="fa fa-eye"></i>SEE PHOTO</a>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/9.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/9.jpg"><i class="fa fa-eye"></i>SEE PHOTO</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/10.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/10.jpg"><i class="fa fa-eye"></i>SEE PHOTO</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/11.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/11.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12  ">
                    <div class="portfolio-sec-wrap">
                        <img class="img-responsive" src="<?php echo base_url();?>assets/img/portfolio/small/12.jpg" alt="" />
                        <div class="overlay">
                            <div class="portfolio-sec-inner">
                                <h3><a href="#"></a></h3>
                                <p></p>
                                <a class="preview" href="<?php echo base_url();?>assets/img/portfolio/big/12.jpg"><i class="fa fa-eye"></i>SEE PHOTO </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- PORTFOLIO SECTION END-->

    <section id="hire-sec">
        <div class="overlay">
            <div class="container">
                <div class="row text-center pad-top-bottom wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".2s">
                    <div class="col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
                        <h1>HIRE ME</h1>
                     <p>Got a project you would like me to work on? Or how about just a friendly chat? Give me an email and we can grab a lovely brew...</p>
                     <br />
                    </div>

                </div>
                <div class="row  move-me wow bounceIn animated" data-wow-duration="1s" data-wow-delay=".4s">
                    <div class="col-lg-6  col-md-6  col-sm-6">
                      <?php if($this->session->flashdata('pesan') === 'success_add') { ?>
                            <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            Your Message has been send.Thank you...
                            </div>
                       <?php } ?> 
                       
                        <?php 
                         $attrib = array('role'=>'form');
                          echo form_open('admin/C_pesan/save_pesan', $attrib); 
                        ?>
                            <div class="form-group">
                                <input type="text" name="fullname" class="form-control" required="required" placeholder="Your Name" />
                            </div><?php echo form_error('fullname'); ?> </p>
                            <div class="form-group">
                                <input type="text" name="email" class="form-control" required="required" placeholder="Your Email" />
                            </div><?php echo form_error('email'); ?> </p>
                            <div class="form-group">
                                <textarea name="pesan" id="pesan" required="required" class="form-control" style="min-height: 100px;" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group">
                             <input type="submit" class="btn custom-btn-one" value="CONTACT ME">
                            
                          <?php echo form_close(); ?>
                            </div>

                    </div>
                    <div class="col-lg-4 col-lg-offset-1  col-md-4  col-md-offset-1 col-sm-4 col-sm-offset-1" id="footer-sec">
                        <h3><strong>MY LOCATION </strong></h3>
                        <p>East Borneo, Melak  </p>

                        <p><i>ADDRESS :</i> RT.10/25 - H.NURDIN STREET, MELAK</p>
                        <p><i>EMAIL :</i>didikhananya@gmail.com</p> 
                        <p>&copy; 2017 All Rights Reserved 
                            <br /> 
                              <a href="<?php echo base_url(); ?>index.php/Login/" style="color:#fff;font-size:11px;" target="_blank">Login</a> </p>
                              
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- HIRE SECTION END-->
    <div class="move-me">
        <a href="#home-sec" class="scrollup"><i class="fa fa-chevron-up"></i></a>
    </div>
    <!-- SCROLL TO TOP SECTION END-->
    <!--  JQUERY CORE SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/jquery-1.10.2.js"></script>
    <!--  BOOTSTRAP SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/bootstrap.js"></script>
    <!--  SCROLL SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/jquery.easing.min.js"></script>
    <!--  WOW ANIMATION SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/wow.min.js"></script>
    <!-- EASY PIE CHART SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/jquery.easypiechart.min.js"></script>
    <!-- PRETTY PHOTO SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/jquery.prettyPhoto.js"></script>
    <!--  STYLE SWITCHER SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/styleSwitcher.js"></script>
    <!--  CUSTOM SCRIPTS -->
    <script src="<?php echo base_url()."assets" ?>/js/custom.js"></script>
    
</body>
</html>
